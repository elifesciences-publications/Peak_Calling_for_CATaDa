#!usr/bin/perl
#filter_ranges
use warnings;

$exp_name = $ARGV[0]; #print "exp_name is $exp_name\n";
$chrom = $ARGV[1];  #print "chrom is $chrom\n";
$replicate = $ARGV[2]; #print "replicate is $replicate\n";
$dir = $ARGV[3]; # root directory path

#$exp_name = "GG_test3"; print "exp_name is $exp_name\n"; $replicate = 1; $chrom = "2L";


print "\nAssigning each GATC fragment its lowest associated FDR for $chrom\n";

open INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Replicate'."$replicate".'_chr'."$chrom".'_ratios.txt' or die "\n Can't open ratio file";
@data_file = <INPUT>;
$num = @data_file;

open INPUT2, "$dir".'/FDR_analysis_for_'."$exp_name".'/FDR_results/chr'."$chrom".'_rep'."$replicate".'_range_data_with_FDR.txt' or die "\n Can't open range data with FDR data file";
@range_FDR = <INPUT2>;
$num2 = @range_FDR;

$ln = 0; while($ln < $num2){
my @range_col = split(/\t/,$range_FDR[$ln]); 	push @AoA, \@range_col; $ln = $ln + 1;} 
		@sorted_range_FDR = sort{$$a[3]<=>$$b[3]}@AoA;    @AoA = (); @range_FDR = ();


open INPUT3, "$dir".'/FDR_analysis_for_'."$exp_name".'/FDR_results/chr'."$chrom".'_rep'."$replicate".'_range_data_for_0FDR.txt' or die "\n Can't open range data with FDR data file";
@range_0_FDR = <INPUT3>;
$num3 = @range_0_FDR;

$ln = 0; while($ln < $num3){
my @zero_range_col = split(/\t/,$range_0_FDR[$ln]); 	push @AoA, \@zero_range_col; $ln = $ln + 1;} 
		@sorted_range_0_FDR = sort{$$a[1]<=>$$b[1]}@AoA;   @AoA = (); @range_0_FDR = (); 

open (OUTPUT, '> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/chr'."$chrom".'_rep'."$replicate".'_each_GATC_frag_with_data_and_lowest_FDR.txt');

open (OUTPUT2, '> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/log.txt');

$ln = 0;
$pos_in_range_file = 0;
$pos_in_0_range_file = 0;

while($ln < $num){
		@col = split(/\t/,$data_file[$ln]);
		$GATC_start = $col[0];  print  OUTPUT2 "\nGATC start is $GATC_start";
		$GATC_end = $col[1];    print OUTPUT2 "\nGATC end is $GATC_end";
		$data = $col[2]; chomp $data;  print OUTPUT2 "\nData is $data";
		
		$ln2 = $pos_in_range_file;  $state = 0; $zerostate = 0;
		
		while($ln2 < $num2){
			#@col2 = split(/\t/,$sorted_range_FDR[$ln2]);
			$FDR = $sorted_range_FDR[$ln2][5]; chomp $FDR;            #print "\nGATC start is $GATC_start , Beginning of range is $col2[3] , End of range is $col2[4] , data is $data\n";
			if(($GATC_start >= $sorted_range_FDR[$ln2][3]) && ($GATC_end <= $sorted_range_FDR[$ln2][4])){
				push (@FDR_array, $FDR); $state = 1; $zerostate = 0; print OUTPUT2 "\nAssociated FDR from normal ranges is $FDR - Range is $sorted_range_FDR[$ln2][3] to $sorted_range_FDR[$ln2][4]";
			}else{$zerostate = 1;}
			
			if(($state == 1) && ($zerostate == 1)){$pos_in_range_file = 0; #temporarily giving up of efficient script!
			if($FDR == 0){$ln2 = $num2;}
				#($ln2 - 1); #$ln2 = $num2;
				}
			
			$ln2 = $ln2 + 1;
		}
		
		if($FDR != 0){
		
		$ln3 = $pos_in_0_range_file; $state = 0; $zerostate = 0;
				
		while($ln3 < $num3){
			#@col3 = split(/\t/,$sorted_range_0_FDR[$ln3]);
			
			if(($GATC_start >= $sorted_range_0_FDR[$ln3][0]) && ($GATC_end <= $sorted_range_0_FDR[$ln3][1])){
				push (@FDR_array, "0"); $state = 1; $zerostate = 0;  print OUTPUT2 "\n0 FDR found"; $ln3 = $num3;
			}else{$zerostate = 1;}
				
			if(($state == 1) && ($zerostate == 1)){$pos_in_0_range_file = 0;  #temporarily giving up of efficient script!
				#($ln3 - 1); #$ln3 = $num3;
				}	
				
			$ln3 = $ln3 + 1;
		}		
		}
		$FDR_array_num = @FDR_array;
		
		if($FDR_array_num > 0){
		
		#print "\nFirst value is FDR_array is $FDR_array[0]";
		
		@sorted_FDR = sort {$a <=> $b} @FDR_array; print OUTPUT2 "\nLowest FDR is $sorted_FDR[0]";
		
		print OUTPUT "$GATC_start\t$GATC_end\t$data\t$sorted_FDR[0]\n";
	}
		
		@FDR_array = ();
		@sorted_FDR = ();
		
		$ln = $ln + 1;
	}


close INPUT;
close INPUT2;
close INPUT3;
close OUTPUT;

exit;				
	  







