#!usr/bin/perl
#merge_FDR_values_and_data
use warnings;


$exp_name = $ARGV[0]; #print "exp_name is $exp_name\n";
$chrom = $ARGV[1];  #print "chrom is $chrom\n";
$replicate = $ARGV[2]; #print "replicate is $replicate\n";
$dir = $ARGV[3]; # root directory path

print "\nMerging FDR and data values\n";
##############################now to merge FDR values and data########################################

open INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/shuffled_data/chr'."$chrom".'_rep'."$replicate".'_shuffled_data.txt'or die "\nCan't open FDR_data file!\n";
@data = <INPUT>;
open INPUT2, "$dir".'/FDR_analysis_for_'."$exp_name".'/FDR_results/chr'."$chrom".'_rep'."$replicate".'_peak_data.txt'or die "\nCan't open peak_data file!\n";
@range_data = <INPUT2>;

open (OUTPUT, '> '."$dir".'/FDR_analysis_for_'."$exp_name".'/FDR_results/chr'."$chrom".'_rep'."$replicate".'_range_data_with_FDR.txt');

$datnum = @data;  #print "\ndata file has $datnum lines!\n";
$rangnum = @range_data;   #print "\nrange file has $rangnum lines!\n";
$ln1 = 0;

while($ln1 < $rangnum){
	@rangdatcol = split(/\t/,$range_data[$ln1]);
	$ln2 = 0;
	$lastcoord = $rangdatcol[4]; chomp $lastcoord;
	
	while($ln2 < $datnum){
		@datcol = split(/\t/,$data[$ln2]);
				if( ($rangdatcol[0] eq $datcol[0]) && ($rangdatcol[1] eq $datcol[1]) && ($rangdatcol[2] eq $datcol[2])){
					
		               	 			print OUTPUT "$rangdatcol[0]\t$rangdatcol[1]\t$rangdatcol[2]\t$rangdatcol[3]\t$lastcoord\t$datcol[3]";
													
													$ln2 = $datnum - 1;
												}
												$ln2 = $ln2 + 1;
											}
											$ln1 = $ln1 + 1;
										}			
		close INPUT;
		close INPUT2;
		close OUTPUT;
		@data = ();
		@range_data = ();
		
		exit;