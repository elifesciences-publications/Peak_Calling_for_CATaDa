#!usr/bin/perl
#merge_peak_files
use warnings;


$exp_name = $ARGV[0];
#$rep_num = $ARGV[1];
$FDR_thres = $ARGV[1];
$dir = $ARGV[2]; # root directory path

print "\nCompiling final peak file\n";


open (OUTPUT, '> '."$dir".'/FDR_analysis_for_'."$exp_name".'/final_peak_file_for_'."$exp_name".'_FDR_'."$FDR_thres".'_with_peak_height_and_highest_assoiciated_FDR.gff'); 

open (OUTPUT2, '> '."$dir".'/FDR_analysis_for_'."$exp_name".'/middle_of_peak_coord_for_'."$exp_name".'_with_peak_height_and_highest_assoiciated_FDR.gff'); 

open INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/peak_GATCs_for_'."$exp_name".'_FDR_'."$FDR_thres".'_with_peak_height_and_highest_assoiciated_FDR.txt' or die "\nCan't open replicate GATC data file\n";
@GATC_data = <INPUT>;


chrom_analysis("2L");
chrom_analysis("2R");
chrom_analysis("3L");
chrom_analysis("3R");
chrom_analysis("4");
chrom_analysis("X");

sub chrom_analysis{  ####don't forget to close bracket!
	
	my $chrom = shift;
	my $chrom2 = "chr"."$chrom"; #print "\n$chrom2\n";

foreach $a (@GATC_data){
@col = split(/\t/,$a);
if($col[0] =~ m/$chrom/){
push @chrom_data, $a;
}
}
$num = @chrom_data; 
$ln = 0;
$state = 0;
$startstate = 0;
#$fragnum = 0;


while($ln < ($num - 1)){
@col = split(/\t/,$chrom_data[$ln]);
@colplus1 = split(/\t/,$chrom_data[$ln + 1]);

if(($col[2] == $colplus1[1]) && ($state == 0)){
	$ratiototal = $col[3] + $colplus1[3]; push @peak_GATC_heights, "$col[1]\t$col[2]\t$col[3]"; push @peak_GATC_heights, "$colplus1[1]\t$colplus1[2]\t$colplus1[3]";
	$FDR = $col[4]; chomp $FDR; $FDRplus1 = $colplus1[4]; chomp $FDRplus1; 
	push @FDRs, $FDR; push @FDR, $FDRplus1[4];
	$state = 1;
	$fragnum = 2;
	$start = $col[1];
	}
	
if(($col[2] == $colplus1[1]) && ($state == 1) && ($startstate == 0)){
	$ratiototal = $ratiototal + $colplus1[3]; push @peak_GATC_heights, "$colplus1[1]\t$colplus1[2]\t$colplus1[3]";
	$FDRplus1 = $colplus1[4]; chomp $FDRplus1; 
	push @FDR, $FDRplus1[4];
	$fragnum = $fragnum + 1;
	}
	
if(($col[2] != $colplus1[1]) && ($state == 1)){
	$ratio_average = $ratiototal / $fragnum; $ratio_average = sprintf("%.2f", $ratio_average);
	my @sorted_FDR = sort {$a <=> $b} @FDRs; $lowFDR = $sorted_FDR[0]; chomp $lowFDR;
	
	print OUTPUT "$chrom2\t.\t$exp_name\t$start\t$col[2]\t1\t$ratio_average\t$lowFDR\t.\n";
	
	foreach $a (@peak_GATC_heights){my @GATCs_col = split(/\t/,$a); push @AoA, \@GATCs_col;}
	@sorted_GATCs = sort{$$b[2]<=>$$a[2]}@AoA;  
	#@sorted_GATCs = sort { $b->[2] <=> $a->[2] } @AoA;
	$mid_peak =  $sorted_GATCs[0][0] + int(($sorted_GATCs[0][1] - $sorted_GATCs[0][0]) / 2); 
	
	
	#print"\nHeighest GATC start is $AoA[0][0] and end is $AoA[0][1] and highest value is $AoA[0][2] ";
	#print"\nnext Heighest GATC start is $AoA[1][0] and end is $AoA[1][1] and highest value is $AoA[1][2] ";	
	
	print OUTPUT2 "$chrom2\t.\t$exp_name midpeak\t$mid_peak\t$mid_peak\t1\t$ratio_average\t$lowFDR\t.\n";
	
	$state = 0;
	@FDRs = (); @peak_GATC_heights = (); @AoA = ();
	}
	
	### last GATC frag??
	
if(($col[2] == $colplus1[1]) && ($state == 1) && ($ln == ($num - 2))){
	$ratio_average = ($ratiototal +  $colplus1[3])/ ($fragnum + 1); $ratio_average = sprintf("%.2f", $ratio_average);
	push @peak_GATC_heights, "$colplus1[1]\t$colplus1[2]\t$colplus1[3]";
	
	push @FDR, $FDRplus1[4];
	my @sorted_FDR = sort {$a <=> $b} @FDRs; $lowFDR = $sorted_FDR[0]; chomp $lowFDR;
	
	print OUTPUT "$chrom2\t.\t$exp_name\t$start\t$colplus1[2]\t1\t$ratio_average\t$lowFDR\t.\n";

	foreach $a (@peak_GATC_heights){my @GATCs_col = split(/\t/,$a); push @AoA, \@GATCs_col;}
	@sorted_GATCs = sort{$$b[2]<=>$$a[2]}@AoA;
	$mid_peak =  $sorted_GATCs[0][0] + int(($sorted_GATCs[0][1] - $sorted_GATCs[0][0]) / 2);
	print OUTPUT2 "$chrom2\t.\t$exp_name midpeak\t$mid_peak\t$mid_peak\t1\t$ratio_average\t$lowFDR\t.\n";	
	
	
	@FDRs = (); @peak_GATC_heights = (); @AoA = ();
	}
	
	$startstate = 0;
	$ln = $ln + 1;
	}
	
	@chrom_data = ();
	
	}
	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	







