#!usr/bin/perl
#find_peaks_and_Assign_FDR
use warnings;


$exp_name = $ARGV[0]; print "exp_name is $exp_name\n";


#$exp_name = "test4"; print "exp_name is $exp_name\n";


chrom_analysis("2L");
chrom_analysis("2R");
chrom_analysis("3L");
chrom_analysis("3R");
chrom_analysis("X");
chrom_analysis("4");

sub chrom_analysis{  ####don't forget to close bracket!
	
	my $chrom = shift;
	my $chrom2 = "chr"."$chrom";


open INPUT, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\chr'."$chrom".'_average_peakfile.txt';
@peakfile = <INPUT>;
$num = @peakfile;

open INPUT2, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep1_range_data_for_0FDR_filtered.txt' or die "\n Can't open 0% range";
@rep1_0FDR = <INPUT2>;
$rep1_0num = @rep1_0FDR;

open INPUT3, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep1_range_data_with_FDR_filtered.txt' or die "\nCan't open rep1 fDR file!";
@rep1_FDR = <INPUT3>;
$rep1_num = @rep1_FDR;


open INPUT4, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep2_range_data_for_0FDR_filtered.txt' or die "\n Can't open 0% range";
@rep2_0FDR = <INPUT4>;
$rep2_0num = @rep2_0FDR;

open INPUT5, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep2_range_data_with_FDR_filtered.txt' or die "\nCan't open rep2 fDR file!";
@rep2_FDR = <INPUT5>;
$rep2_num = @rep2_FDR;

#open INPUT6, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep3_range_data_for_0FDR_filtered.txt' or die "\n Can't open 0% range";
#@rep3_0FDR = <INPUT6>;
#$rep3_0num = @rep3_0FDR;

#open INPUT7, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep3_range_data_with_FDR_filtered.txt' or die "\nCan't open rep3 fDR file!";
#@rep3_FDR = <INPUT7>;
#$rep3_num = @rep3_FDR;

open (OUTPUT, '> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_final_peak_FDR_data.txt');


$ln1 = 0;

while($ln1 < $num){
		@col = split(/\t/,$peakfile[$ln1]);
		$coord = $col[0];
		$ratio = $col[1];
		chomp $ratio;
		
		$rep1_0_state = 0;
		$rep1_state = 0;
		$rep2_0_state = 0;
		$rep2_state = 0;
		#$rep3_0_state = 0;
		#$rep3_state = 0;
		
		$rep1_FDR = ();
		$rep2_FDR = ();
		#$rep3_FDR = ();
		
		
		$ln2 = 0;
		  while($ln2 < $rep1_0num){
		  	@repcol = split(/\t/,$rep1_0FDR[$ln2]);
		  	  if(($coord >= $repcol[0]) && ($coord <= $repcol[1])){$rep1_0_state = 1; $ln2 = ($rep1_0num - 1); push (@mini_rep1, "0");}
		  	 $ln2 = $ln2 + 1;
		  	}
		  	 
		$ln2 = 0;
		  while($ln2 < $rep1_num){
		  	@repcol = split(/\t/,$rep1_FDR[$ln2]);
		  	  if(($coord >= $repcol[3]) && ($coord <= $repcol[4])){$rep1_state = 1;  push (@mini_rep1, "$repcol[5]"); }
		  	 $ln2 = $ln2 + 1;
		  	}	
		  	
		  	
		$ln2 = 0;
		  while($ln2 < $rep2_0num){
		  	@repcol = split(/\t/,$rep2_0FDR[$ln2]);
		  	  if(($coord >= $repcol[0]) && ($coord <= $repcol[1])){$rep2_0_state = 1; $ln2 = ($rep2_0num - 1); push (@mini_rep2, "0");}
		  	 $ln2 = $ln2 + 1;
		  	}
		  	 
		$ln2 = 0;
		  while($ln2 < $rep2_num){
		  	@repcol = split(/\t/,$rep2_FDR[$ln2]);
		  	 if(($coord >= $repcol[3]) && ($coord <= $repcol[4])){$rep2_state = 1; push (@mini_rep2, "$repcol[5]");}
		  	 $ln2 = $ln2 + 1;
		  	}		  	
		  	
		#$ln2 = 0;
		#  while($ln2 < $rep3_0num){
		#  	@repcol = split(/\t/,$rep3_0FDR[$ln2]);
		#  	 if(($coord >= $repcol[0]) && ($coord <= $repcol[1])){$rep3_0_state = 1; $ln2 = ($rep3_0num - 1); push (@mini_rep3, "0");}
		#  	 $ln2 = $ln2 + 1;
		#  	}
		  	 
	#	$ln2 = 0;
		#  while($ln2 < $rep3_num){
		#  	@repcol = split(/\t/,$rep3_FDR[$ln2]);
		#  	  if(($coord >= $repcol[3]) && ($coord <= $repcol[4])){$rep3_state = 1; push (@mini_rep3, "$repcol[5]");}
		 # 	 $ln2 = $ln2 + 1;
		 # 	}		  		  	
		  	
		  	
if((($rep1_0_state == 1) || ($rep1_state == 1))	&&	(($rep2_0_state == 1) || ($rep2_state == 1)) ){
	
	@sorted_1 = sort {$a <=> $b} @mini_rep1; $rep1_FDR = $sorted_1[0]; @sorted_1 = (); @mini_rep1 = ();
	@sorted_2 = sort {$a <=> $b} @mini_rep2; $rep2_FDR = $sorted_2[0]; @sorted_2 = (); @mini_rep2 = ();	
	#@sorted_3 = sort {$a <=> $b} @mini_rep3; $rep3_FDR = $sorted_3[0]; @sorted_3 = (); @mini_rep3 = ();	
	  	
		  	if($rep1_0_state == 1){push (@FDRs, "0");}
		  	if($rep1_state == 1){push (@FDRs, "$rep1_FDR");}
		  	if($rep2_0_state == 1){push (@FDRs, "0");}
		  	if($rep2_state == 1){push (@FDRs, "$rep2_FDR");}		  	
		  #	if($rep3_0_state == 1){push (@FDRs, "0");}
		  #	if($rep3_state == 1){push (@FDRs, "$rep3_FDR");}		  	
		  	
		  	@sorted_FDRs = sort {$b <=> $a} @FDRs;
		  	$final_FDR = $sorted_FDRs[0];
		  	chomp $final_FDR;
		  	print OUTPUT "$chrom\t$ratio\t$final_FDR\t$coord\n";
		  	@FDRs = ();
		  	@sorted_FDRs = ();
		  }
		  
		  $ln1 = $ln1 + 1;
		}
		
		close OUTPUT;
		close INPUT; @peakfile = ();
		close INPUT2; @rep1_0FDR = ();
		close INPUT3; @rep1_FDR = (); 	
		close INPUT4; @rep2_0FDR = (); 	
		close INPUT5; @rep2_FDR = ();	
		#close INPUT6; @rep3_0FDR = ();
	#	close INPUT7; @rep3_FDR = ();
		
		print "\nAssign peaks for chrom $chrom finished!";
	}
		
	exit;	  	
		  