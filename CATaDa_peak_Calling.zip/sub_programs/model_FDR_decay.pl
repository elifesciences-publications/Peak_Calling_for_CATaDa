#!usr/bin/perl
#model_FDR_decay
use warnings;


#$exp_name = $ARGV[0]; print "exp_name is $exp_name\n";
#$chrom = $ARGV[1];  print "chrom is $chrom\n";
#$replicate = $ARGV[2]; print "replicate is $replicate\n";

$exp_name = "GG_test"; print "exp_name is $exp_name\n";
$chrom = "2L";  print "chrom is $chrom\n";
$replicate = "1"; print "replicate is $replicate\n";



###################################### now to model exponential decay of FDR values  #############################
#if($chrom =~ m/4/){print "\nskipping modelling for chrom 4!";
#	open OUTPUT, ('> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep'."$replicate".'_FDR_data_full.txt');
#  open INPUT, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\shuffled_data\chr'."$chrom".'_rep'."$replicate".'_shuffled_data.txt';
#	@file = <INPUT>;
#	foreach(@file){print OUTPUT $_;}
			
	
#	}




#else{




open INPUT, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\shuffled_data\chr'."$chrom".'_rep'."$replicate".'_shuffled_data.txt';
@FDR_data = <INPUT>;
$FDR_num = @FDR_data;

$max_probe  = 6;
$probe = 2;

while($probe < $max_probe){
	
	$ln = 0;
	while($ln < $FDR_num){
		@col = split(/\t/,$FDR_data[$ln]);
		
		if($probe == $col[1]){push (@thres_values, $col[2]); push (@FDR_values, $col[3]); }
		
		$ln = $ln + 1;
	}
	$array_num = @thres_values;

$iter = 0;	
while($iter < 500000){
$diff_total = 0;
$a = rand(10);
$b = rand(10);

$ln2 = 0;
while($ln2 < $array_num){
	$predict_FDR = $a * ($thres_values[$ln2] ** -$b);
	$diff = abs ($FDR_values[$ln2] - $predict_FDR);
	$diff_total = $diff_total + $diff;
	$ln2 = $ln2 + 1;
}

push (@diff_array, "$a\t$b\t$diff_total");

#open LOG, '>> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\chr'."$chrom".'_'."$probe".'probes_curvefit_iterations.txt';
#print LOG "$a\t$b\t$diff_total\n"; #print "$a\t$b\t$diff_total\n";
#close LOG;

$iter = $iter + 1;
} 
$diff_num = @diff_array;
$ln3 = 0;

while($ln3 < $diff_num){
	my @col2 = split(/\t/,$diff_array[$ln3]);
	push @AoA, \@col2;
	$ln3 = $ln3 + 1;	    
	 		}
@sorted_array = sort{$$a[2]<=>$$b[2]}@AoA;

$variable1 = $sorted_array[0][0];
$variable2 = $sorted_array[0][1];

open LOG, '>> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\chr'."$chrom".'_rep'."$replicate".'_exponential_variables.txt';
print LOG "$chrom\t$probe\t$variable1\t$variable2\n"; print "$chrom\t$probe\t$variable1\t$variable2\n";
close LOG;

@thres_values = ();
@FDR_values = ();
@diff_array = ();
@AoA = ();
@sorted_array = ();

$probe = $probe + 1;
}
close INPUT;
@FDR_data = ();
print "\ncurve fit done!\n";

}

exit;