#!usr/bin/perl
#filter_ranges
use warnings;
$exp_name = $ARGV[0]; print "exp_name is $exp_name\n";

#$exp_name = "mbadult_new_rep_analysis"; print "exp_name is $exp_name\n";

chrom_analysis("2L");
chrom_analysis("2R");
chrom_analysis("3L");
chrom_analysis("3R");
chrom_analysis("4");
chrom_analysis("X");

sub chrom_analysis{  ####don't forget to close bracket!
	
	my $chrom = shift;


open INPUT, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr'."$chrom".'_ratios.txt' or die "\n Can't open rep1";
@rep1 = <INPUT>;
$num = @rep1;

open INPUT2, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr'."$chrom".'_ratios.txt' or die "\n Can't open rep2";
@rep2 = <INPUT2>;

#open INPUT3, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr'."$chrom".'_ratios.txt' or die "\n Can't open rep3";
#@rep3 = <INPUT3>;

$ln = 1;
$state = 0;

while($ln < $num){
		@col1 = split(/\t/,$rep1[$ln]);
		@col1minus1 = split(/\t/,$rep1[$ln - 1]);
		@col2 = split(/\t/,$rep2[$ln]);
		@col2minus1 = split(/\t/,$rep2[$ln - 1]);
		#@col3 = split(/\t/,$rep3[$ln]);
		#@col3minus1 = split(/\t/,$rep3[$ln - 1]);
				
	  
	
	if((($col1minus1[1] < 1) || ($col2minus1[1] < 1)) && (($col1[1] >= 1) && ($col2[1] >= 1) ) && ($state == 0)){$start = $col1[0]; $state = $state + 1;}
	if((($col1minus1[1] >= 1) && ($col2minus1[1] >= 1) ) && ($state > 0)){$state = $state + 1;} 
	if( ($col1[0] - $col1minus1[0]) > 1000){$state = 0;}

	if((($col1[1] < 1) || ($col2[1] < 1)) && ($state >= 6) ){
		     $endofrange = $col1minus1[0];
		     									push (@all_1_array, "$start\t$endofrange\n");
		               	 			open LOG, '>> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\chr'."$chrom".'_range_data_all_above1.txt';
													print LOG "$start\t$endofrange\n";
													close LOG;  #print "\nrange info assigned";
													$state = 0;
												}
			if(($col1[1] < 1) || ($col2[1] < 1) ){$state = 0;}	
						
												$ln = $ln + 1;

											}
@rep1 = ();
@rep2 = ();
#@rep3 = ();
close INPUT;
close INPUT2;
#close INPUT3;




$rep = 1;
while($rep < 3){
	
open INPUT, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep'."$rep".'_range_data_for_0FDR.txt' or die "\n Can't open 0% range";
@rep1_0FDR = <INPUT>;
$rep1_0num = @rep1_0FDR;

open INPUT2, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep'."$rep".'_range_data_with_FDR.txt' or die "\nCan't open rep1 fDR file!";
@rep1_FDR = <INPUT2>;
$rep1_num = @rep1_FDR;

$num = @all_1_array;

$ln1 = 0;

while($ln1 < $rep1_0num){
	@col = split(/\t/,$rep1_0FDR[$ln1]);
	
	$ln2 = 0;
	while($ln2 < $num){
		@col_all_1 = split(/\t/,$all_1_array[$ln2]);
		if(($col[0] >= $col_all_1[0]) && ($col[1] <= $col_all_1[1])){
			
		               	 			open LOG, '>> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep'."$rep".'_range_data_for_0FDR_filtered.txt';
													print LOG "$rep1_0FDR[$ln1]";
													close LOG;  #print "\nrange info assigned";
												}
						$ln2 = $ln2 + 1;
					}
					$ln1 = $ln1 + 1;
				}

$ln1 = 0;

while($ln1 < $rep1_num){
	@col = split(/\t/,$rep1_FDR[$ln1]);
	
	$ln2 = 0;
	while($ln2 < $num){
		@col_all_1 = split(/\t/,$all_1_array[$ln2]);
		if(($col[3] >= $col_all_1[0]) && ($col[4] <= $col_all_1[1])){
			
		               	 			open LOG, '>> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\FDR_results\chr'."$chrom".'_rep'."$rep".'_range_data_with_FDR_filtered.txt';
													print LOG "$rep1_FDR[$ln1]";
													close LOG;  #print "\nrange info assigned";
												}
						$ln2 = $ln2 + 1;
					}
					$ln1 = $ln1 + 1;
				}

@rep1_0FDR = ();
@rep1_FDR = ();
close INPUT;
close INPUT2;			
				
$rep = $rep + 1;
}





###close bracket for sub:
}










