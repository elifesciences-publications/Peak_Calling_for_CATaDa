#!usr/bin/perl
#model_large_peak_variables
use warnings;


$exp_name = $ARGV[0]; print "exp_name is $exp_name\n";
$chrom = $ARGV[1];  print "chrom is $chrom\n";
$replicate = $ARGV[2]; print "replicate is $replicate\n";





open INPUT, 'c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\chr'."$chrom".'_rep'."$replicate".'_exponential_variables.txt' or die "\nCan't open file";
@var_data = <INPUT>;
$var_num = @var_data;

	$varB_total = 0;
	$ln = 0;
	while($ln < $var_num){
		@col = split(/\t/,$var_data[$ln]);
		
		push (@probe_values, $col[1]); push (@varB_values, $col[3]); $varA_total = $varA_total + $col[2];
		
		$ln = $ln + 1;
	}
	$aver_varA = $varA_total / $var_num;
	


$iter = 0;	
while($iter < 200000){
$diff_total = 0;
$c = rand(2);
$d = rand(2);

$ln2 = 0;
while($ln2 < $var_num){
	$predict_varB = (-$c*$probe_values[$ln2]) - $d;
	$diff = abs ($varB_values[$ln2] - $predict_varA);
	$diff_total = $diff_total + $diff;
	$ln2 = $ln2 + 1;
}

push (@diff_array, "$c\t$d\t$diff_total");

#open LOG, '>> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\chr'."$chrom".'_probes_curvefit_iterations_varA.txt';
#print LOG "$a\t$b\t$diff_total\n"; #print "$a\t$b\t$diff_total\n";
#close LOG;

$iter = $iter + 1;
} 
$diff_num = @diff_array;
$ln3 = 0;

while($ln3 < $diff_num){
	my @col2 = split(/\t/,$diff_array[$ln3]);
	push @AoA, \@col2;
	$ln3 = $ln3 + 1;	    
	 		}
@sorted_array = sort{$$a[2]<=>$$b[2]}@AoA;

$variable1 = $sorted_array[0][0]; #print "\n$variable1";
$variable2 = $sorted_array[0][1]; #print "\n$variable2";

open LOG, '>> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\chr'."$chrom".'_exponential_variables_for_varB_decay.txt';
print LOG "$chrom\t$variable1\t$variable2\n"; #print "$chrom\t$probe\t$aver_varA\t$variable1\t$variable2\n";
close LOG;


@diff_array = ();
@AoA = ();
@sorted_array = ();

#close INPUT;

	#$probe = 2;
	
	#while($probe < 20){		
			
			#$varA = $variable1 * exp(-$variable2*$probe);
			
			
			#open LOG, '>> c:\DamID_analysis\FDR_analysis_for_'."$exp_name".'\logfiles\chr'."$chrom".'_rep'."$replicate".'_exponential_variables.txt';
			#print LOG "$chrom\t$probe\t$varA\t$aver_varB\n";
			#close LOG;
			
			#$probe = $probe + 1;
		#}

exit;