#!usr/bin/perl
#merge_peak_files
use warnings;


$exp_name = $ARGV[0];
$rep_num = $ARGV[1];
$FDR_thres = $ARGV[2];
$dir = $ARGV[3]; # root directory path

print "\nAssociating final peaks with highest FDR and average height\n";


open (OUTPUT, '> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/peak_GATCs_for_'."$exp_name".'_FDR_'."$FDR_thres".'_with_peak_height_and_highest_assoiciated_FDR.txt'); 


if($rep_num == 3){
	
open INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/GATC_frags_forming_peaks.gff' or die "\nCan't open GATC_frags_forming_peaks file\n";
@peaks = <INPUT>;

chrom_analysis("2L");
chrom_analysis("2R");
chrom_analysis("3L");
chrom_analysis("3R");
chrom_analysis("4");
chrom_analysis("X");

sub chrom_analysis{  ####don't forget to close bracket!
	
	my $chrom = shift;
	my $chrom2 = "chr"."$chrom"; print "\n$chrom2\n";


open INPUT2, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/chr'."$chrom".'_rep1_each_GATC_frag_with_data_and_lowest_FDR.txt' or die "\nCan't open replicate 1 FDR file\n";
@rep1 = <INPUT2>;
open INPUT3, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/chr'."$chrom".'_rep2_each_GATC_frag_with_data_and_lowest_FDR.txt' or die "\nCan't open replicate 2 FDR file\n";
@rep2 = <INPUT3>;
open INPUT4, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/chr'."$chrom".'_rep3_each_GATC_frag_with_data_and_lowest_FDR.txt' or die "\nCan't open replicate 3 FDR file\n";
@rep3 = <INPUT4>;

foreach $a (@peaks){
@col = split(/\t/,$a);
if($col[0] =~ m/$chrom/){push @chrom_peaks, "$col[1]\t$col[2]";}
}

$peaks_num = @chrom_peaks;
$ln = 0;
$state = 0;

while($ln < $peaks_num){
	@peak_col = split(/\t/,$chrom_peaks[$ln]); $start = $peak_col[0]; $end = $peak_col[1]; chomp $end;

foreach $a (@rep1){@col = split(/\t/,$a); if($col[0] == $start){$data1 = $col[2]; $FDR1 = $col[3];}}

foreach $a (@rep2){@col = split(/\t/,$a); if($col[0] == $start){$data2 = $col[2]; $FDR2 = $col[3];}}

foreach $a (@rep3){@col = split(/\t/,$a); if($col[0] == $start){$data3 = $col[2]; $FDR3 = $col[3];}}

$average = (($data1 + $data2 + $data3)  / 3);  $average = sprintf("%.3f", $average);

push (@FDRs, ($FDR1, $FDR2, $FDR3));  my @sorted_FDRs = sort {$b <=> $a} @FDRs; $highFDR = $sorted_FDRs[0];

print OUTPUT "$chrom2\t$start\t$end\t$average\t$highFDR";

@FDRs = ();
$ln = $ln + 1;
}
@chrom_peaks = (); @rep1 = (); @rep2 = (); @rep3 = ();
}
}

if($rep_num == 2){
	
open INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/GATC_frags_forming_peaks.gff' or die "\nCan't open GATC_frags_forming_peaks file\n";
@peaks = <INPUT>;

chrom_analysis2("2L");
chrom_analysis2("2R");
chrom_analysis2("3L");
chrom_analysis2("3R");
chrom_analysis2("4");
chrom_analysis2("X");

sub chrom_analysis2{  ####don't forget to close bracket!
	
	my $chrom = shift;
	my $chrom2 = "chr"."$chrom"; print "\n$chrom2\n";


open INPUT2, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/chr'."$chrom".'_rep1_each_GATC_frag_with_data_and_lowest_FDR.txt' or die "\nCan't open replicate 1 FDR file\n";
@rep1 = <INPUT2>;
open INPUT3, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/chr'."$chrom".'_rep2_each_GATC_frag_with_data_and_lowest_FDR.txt' or die "\nCan't open replicate 2 FDR file\n";
@rep2 = <INPUT3>;


foreach $a (@peaks){
@col = split(/\t/,$a);
if($col[0] =~ m/$chrom/){push @chrom_peaks, "$col[1]\t$col[2]";}
}

$peaks_num = @chrom_peaks;
$ln = 0;
$state = 0;

while($ln < $peaks_num){
	@peak_col = split(/\t/,$chrom_peaks[$ln]); $start = $peak_col[0]; $end = $peak_col[1]; chomp $end;

foreach $a (@rep1){@col = split(/\t/,$a); if($col[0] == $start){$data1 = $col[2]; $FDR1 = $col[3];}}

foreach $a (@rep2){@col = split(/\t/,$a); if($col[0] == $start){$data2 = $col[2]; $FDR2 = $col[3];}}



$average = (($data1 + $data2)  / 2); $average = sprintf("%.3f", $average);

push (@FDRs, ($FDR1, $FDR2));  my @sorted_FDRs = sort {$b <=> $a} @FDRs; $highFDR = $sorted_FDRs[0];

print OUTPUT "$chrom2\t$start\t$end\t$average\t$highFDR";

@FDRs = ();
$ln = $ln + 1;
}
@chrom_peaks = (); @rep1 = (); @rep2 = (); 
}
}

if($rep_num == 1){
	
open INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/GATC_frags_forming_peaks.gff' or die "\nCan't open GATC_frags_forming_peaks file\n";
@peaks = <INPUT>;

chrom_analysis3("2L");
chrom_analysis3("2R");
chrom_analysis3("3L");
chrom_analysis3("3R");
chrom_analysis3("4");
chrom_analysis3("X");

sub chrom_analysis3{  ####don't forget to close bracket!
	
	my $chrom = shift;
	my $chrom2 = "chr"."$chrom"; print "\n$chrom2\n";


open INPUT2, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/chr'."$chrom".'_rep1_each_GATC_frag_with_data_and_lowest_FDR.txt' or die "\nCan't open replicate 1 FDR file\n";
@rep1 = <INPUT2>;


foreach $a (@peaks){
@col = split(/\t/,$a);
if($col[0] =~ m/$chrom/){push @chrom_peaks, "$col[1]\t$col[2]";}
}

$peaks_num = @chrom_peaks;
$ln = 0;
$state = 0;

while($ln < $peaks_num){
	@peak_col = split(/\t/,$chrom_peaks[$ln]); $start = $peak_col[0]; $end = $peak_col[1]; chomp $end;

foreach $a (@rep1){@col = split(/\t/,$a); if($col[0] == $start){$data1 = $col[2]; $FDR1 = $col[3]; chomp $FDR1;}}


print OUTPUT "$chrom2\t$start\t$end\t$data1\t$FDR1\n";

@FDRs = ();
$ln = $ln + 1;
}
@chrom_peaks = (); @rep1 = ();
}
}